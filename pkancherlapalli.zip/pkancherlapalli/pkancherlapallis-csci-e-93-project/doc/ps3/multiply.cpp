#include	<stdio.h>
#include	<stdlib.h>

#include "multiply.h"
#define MAX_CHAR 7  /* take in characters that fit in 16 bit*/
#define MAX_BITS 17 /* max loops in multiplication and division*/

#define MAX_ALLOC 16



int main(int ac, char** av)
{
	int c;
	while (process() != -1)
	{
		output_str("Done.press Q to quit");
		if (c = getc(stdin) == 'Q')
			break;
		else
			while (getc(stdin) != '\n');
	}
	
	return 0;
}

int process()
{

	//char result[MAX_CHAR] = "";
	int val1 = 0, val2 = 0;

	output_str("Enter a value:");
	char* s1 = NULL;
	char* s2 = NULL;
	char* result = NULL;

	s1 = (char*)malloc(MAX_ALLOC);
	if (input_str(&s1) == -1)
	{
		free(s1);
		return -1;
	}

	if (convert_str_to_int(&s1, &val1) == -1)
	{
		free(s1);
		return -1;
	}

	output_str("Enter second value:");

	s2 = (char*)malloc(MAX_ALLOC);
	if (input_str(&s2) == -1)
	{
		free(s1); free(s2);
		return -1;
	}

	if (convert_str_to_int(&s2, &val2) == -1)
	{
		free(s1); free(s2);
		return -1;
	}
	int hi, lo;
	int prod = multiply_int(val1, val2);
	if (prod >0 && prod > 0x7FFF)
	{
		output_str("value is greater than 16 bit max value and is truncated.");
	}
	hi = prod >> 16;
	
	/* sign extend lo bits*/
	if (hi >> 15)
	{
		lo = prod & 0xFFFFFFFF;
		lo = 0x80000000 | lo;
	}
	else
	{
		lo = prod & 0x0000FFFF;
		lo = 0x00000000 | lo;
	}
	result = (char*)malloc(MAX_ALLOC);
	convert_int_to_str(lo, &result);

	output_str(result);

	free(s1);
	free(s2);
	free(result);
	return 0;
}

/*read in the number from stdin and store in string*/
int input_str(char** str)
{
	int curchar;
	int index = 0;
	int ishyphen = 0;
	while ((curchar = fgetc(stdin)) != EOF)
	{
		if (curchar == '\n') break;
		if (curchar == ' ') continue;

		if (index == 0 && curchar == '-')
		{
			(*str)[index] = curchar;
			ishyphen = 1;
			index++; 
			continue;
		}

		if (index == 1 && ishyphen == 1 && curchar == '-')
		{
			continue;
		}
		/*
		if an invalid character other than digit is found.
		print an error message and exit
		*/
		if (curchar < '0' || curchar > '9')
		{
			output_str("Not a valid number.");
			return -1;
		}
		if (index == MAX_ALLOC)
		{
			*str = (char*)realloc(*str, 2 * MAX_ALLOC);
		}
		(*str)[index] = curchar;
		index++;
	}

	(*str)[index] = '\0';
	return 0;
}

/* output the resultant value of multiplication to stdout*/
void output_str(char* str)
{
	int index = 0;

	while (str[index] != '\0')
	{
		fputc(str[index], stdout);
		index++;
	}
	fputc('\n', stdout);
	return;
}

/* converts string to 2's complement integer*/
int convert_str_to_int(char** str, int* value)
{
	int index = 0;
	int islz = 0;
	*value = 0;
	int c;

	if ((*str)[0] == '\0')
	{
		output_str("Empty string. No number specified.");
		return -1;
	}

	while ((*str)[index] != '\0')
	{
		c = (*str)[index];
		if (index == 0 &&  c == '-')
		{
			islz = 1;
			index++;
			continue;
		}

		/* is +ve and number greater than 32767*/
		if ((*value - 0xccc) > 0 && islz == 0 && c > 7)
		{
			output_str("number out of range.");
			return -1;
		}
		/* is -ve and number less than -32768 */
		if ((*value - 0xccc) > 0 && islz == 1 && c > 8)
		{
			output_str("number out of range");
			return -1;
		}
		/*
		subtract ascii value of 0 from the current characters ascii value and
		multiply with old value by 10 since we moved a digit.
		*/

		*value = multiply_int(*value, 10) + (c - '0');
		index++;
	}
	if (islz == 1)
	{
		*value = ~(*value) + 1;
	}

	return 0;
}

/*
converts the integer value calculated from multiplication to string for output.
*/
int convert_int_to_str(int value, char** str)
{
	int dividend = value;
	int quotient = 0;
	int nchars = -1;
	int index = 0;
	char s[MAX_CHAR] = "";

	if (value < 0 || (value >> 15))
	{
		(*str)[index++] = '-';
	}

	if (value == 0)
	{
		(*str)[index++] = '0';
	}
	while (dividend != 0)
	{
		nchars++;
		if (nchars == MAX_CHAR)
		{
			output_str("value is beyond the 16 bit range and is truncated.");
			break;
		}
		s[nchars] = divide_int(dividend, 10, &quotient) + '0';
		dividend = quotient;
	}

	while (nchars >= 0)
	{
		(*str)[index++] = s[nchars--];
	}
	(*str)[index] = '\0';
	return 0;
}

/*
use bitwise multiplication algorithm as done in Hennesey and Patterson
*/
int multiply_int(int v1, int v2)
{
	int multiplicand = v1;
	int multiplier = v2;
	int res = 0;
	int islz = 0;
	unsigned int mask = 0x0001;

	/* take the negative number as multiplicand if one of them is -ve*/
	if (v1 > 0 && v2 < 0)
	{
		multiplicand = v2;
		multiplier = v1;
		islz = 1;
	}
	if (v1 < 0 && v2 > 0) islz = 1;

	/*if both are -ve then reverse the sign of both as the result is +ve.*/
	if (v1 < 0 && v2 < 0)
	{
		multiplicand = -v1;
		multiplier = -v2;
	}

	for (int i = 1; i < MAX_BITS; i++)
	{
		if (multiplier == 0) break;
		if (multiplier & mask)
		{
			res = res + multiplicand;
		}
		multiplicand = multiplicand << 1;
		multiplier = multiplier >> 1;
	}
	return res;
}


/*
divide algorithm as in Hennesey and Patterson
this function is called multiple times while converting int to string to get the decimal value
the second parameter is always 10. returns remainder and quotient
*/
int divide_int(int v1, int v2, int* quotient)
{
	int divisor = 0;
	int remainder = 0;
	int index = 0;
	int temp = 1;
	int islz1 = 0;
	int islz2 = 0;
	*quotient = 0;

	/*
	just take the absolute values  and do unsigned divide
	and add the sign while cosntructing the string
	*/
	if (v1 < 0)
	{
		v1 = -v1; islz1 = 1;
	}
	if (v2 < 0)
	{
		v2 = -v2;
		islz2 = 1;
	}

	if (v1 == 0)
	{
		return 0;
	}
	if (v1 == v2)
	{
		*quotient = 1;
		return 0;
	}
	if (v1 < v2)
	{
		*quotient = 0;
		return v1;
	}

	remainder = v1;
	divisor = v2;
	while (remainder > divisor)
	{
		divisor = divisor << 1;
		temp = temp << 1;
	}

	divisor = divisor >> 1;
	temp = temp >> 1;

	while (temp > 0)
	{
		if (remainder >= divisor)
		{
			remainder = remainder - divisor;
			*quotient = *quotient | temp;
		}

		divisor = divisor >> 1;
		temp = temp >> 1;
	}
	if (islz1 ^ islz2)
	{
		*quotient = -(*quotient);
	}
	return remainder;
}
