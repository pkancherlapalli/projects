#ifndef UTILITY_H_INCLUDED
#define UTILITY_H_INCLUDED

int readline(FILE* , char* );
int findtoken(char* , char );

#endif // UTILITY_H_INCLUDED
