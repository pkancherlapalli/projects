#ifndef INSTRUCTSTR_H_INCLUDED
#define INSTRUCTSTR_H_INCLUDED
#include "datatype.h"

void do_str(char* , struct instruction* );
void do_rtypestr(char* , struct instruction* , int );
void get_register(char* , int );

#endif // INSTRUCTSTR_H_INCLUDED
