#ifndef INSTRLIST_H_INCLUDED
#define INSTRLIST_H_INCLUDED

#include "instruction.h"

void listrelease(struct instruction* );
void write2list(struct instruction* , struct instruction* );

#endif // INSTRLIST_H_INCLUDED
