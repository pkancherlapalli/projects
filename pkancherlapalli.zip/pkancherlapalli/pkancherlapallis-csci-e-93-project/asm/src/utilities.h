#ifndef UTILITIES_H_INCLUDED
#define UTILITIES_H_INCLUDED

int readline(FILE* , char* );
int findtoken(char* , char );
void getsubstring(char* ,int ,int , char* );
void trim(char* );
void stoupper(char* );
#endif // UTILITIES_H_INCLUDED
