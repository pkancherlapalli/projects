#ifndef MULTIPLY_H_INCLUDED
#define MULTIPLY_H_INCLUDED

int		input_str(char**);
void	output_str(char*);
int		convert_str_to_int(char**, int*);
int 	convert_int_to_str(int, char**);
int		multiply_int(int, int);
int		divide_int(int v1, int v2, int* quotient);
int		process();

#endif // MULTIPLY_H_INCLUDED
