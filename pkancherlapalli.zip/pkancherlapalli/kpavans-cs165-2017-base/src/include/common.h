// This file includes shared constants and other values.
#ifndef COMMON_H__
#define COMMON_H__

#define SOCK_PATH "cs165_unix_socket"

#endif  // COMMON_H__
