README for CS 61 Problem Set 2
------------------------------
The Binary Bomb lab is self-graded; you don't actually need to turn
anything in. However, if you have notes for the course staff or graders,
*such as any collaborators or resources you want to acknowledge*, fill
out this file and commit it to your code.seas.harvard.edu repository.

NOTES FOR THE GRADER (if any):
