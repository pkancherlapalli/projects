// vim: set tabstop=8: -*- tab-width: 8 -*-
#include "kernel.h"
#include "lib.h"

// k-hardware.c
//
//    Grody functions for interacting with x86 hardware.


// hardware_init
//    Initialize hardware. Calls other functions bellow.

static void segments_init(void);
static void interrupt_init(void);
static void virtual_memory_init(void);

void hardware_init(void) {
    segments_init();
    interrupt_init();
    virtual_memory_init();
}


// segments_init
//    Set up segment registers and interrupt descriptor table.
//
//    The segment registers distinguish the kernel from applications:
//    the kernel runs with segments SEGSEL_KERN_CODE and SEGSEL_KERN_DATA,
//    and applications with SEGSEL_APP_CODE and SEGSEL_APP_DATA.
//    The kernel segment runs with full privilege (level 0), but application
//    segments run with less privilege (level 3).
//
//    The interrupt descriptor table tells the processor where to jump
//    when an interrupt or exception happens. See k-interrupt.S.
//
//    The taskstate_t, segmentdescriptor_t, and pseduodescriptor_t types
//    are defined by the x86 hardware.

// Segment selectors
#define SEGSEL_KERN_CODE	0x8		// kernel code segment
#define SEGSEL_KERN_DATA	0x10		// kernel data segment
						// (SEE ALSO k-interrupt.S)
#define SEGSEL_APP_CODE		0x18		// application code segment
#define SEGSEL_APP_DATA		0x20		// application data segment
#define SEGSEL_TASKSTATE	0x28		// task state segment

// The task descriptor defines the state the processor should set up
// when taking an interrupt.
static struct taskstate kernel_task_descriptor;

// Segments
static struct segmentdescriptor segments[] = {
	SEG_NULL,				// ignored
	SEG(STA_X | STA_R, 0, 0xFFFFFFFF, 0),	// SEGSEL_KERN_CODE
	SEG(STA_W, 0, 0xFFFFFFFF, 0),		// SEGSEL_KERN_DATA
	SEG(STA_X | STA_R, 0, 0xFFFFFFFF, 3),	// SEGSEL_APP_CODE
	SEG(STA_W, 0, 0xFFFFFFFF, 3),		// SEGSEL_APP_DATA
	SEG_NULL /* defined below */		// SEGSEL_TASKSTATE
};
static struct pseudodescriptor global_descriptor_table = {
	sizeof(segments) - 1,
	(uintptr_t) segments
};

// Interrupt descriptors
static struct gatedescriptor interrupt_descriptors[256];
static struct pseudodescriptor interrupt_descriptor_table = {
	sizeof(interrupt_descriptors) - 1,
	(uintptr_t) interrupt_descriptors
};

// Particular interrupt handler routines
extern void (*sys_int_handlers[])(void);
extern void default_int_handler(void);
extern void gpf_int_handler(void);
extern void pagefault_int_handler(void);
extern void timer_int_handler(void);

void segments_init(void) {
    // Set task state segment
    segments[SEGSEL_TASKSTATE >> 3]
	= SEG16(STS_T32A, (uint32_t) &kernel_task_descriptor,
		sizeof(struct taskstate), 0);
    segments[SEGSEL_TASKSTATE >> 3].sd_s = 0;

    // Set up kernel task descriptor, so we can receive interrupts
    kernel_task_descriptor.ts_esp0 = KERNEL_STACK_TOP;
    kernel_task_descriptor.ts_ss0 = SEGSEL_KERN_DATA;

    // Set up interrupt descriptor table.
    // Most interrupts are effectively ignored
    memset(interrupt_descriptors, 0, sizeof(interrupt_descriptors));
    for (int i = 16;
	 i < sizeof(interrupt_descriptors) / sizeof(struct gatedescriptor);
	 ++i)
	SETGATE(interrupt_descriptors[i], 0,
		SEGSEL_KERN_CODE, default_int_handler, 0);

    // Timer interrupt
    SETGATE(interrupt_descriptors[INT_TIMER], 0,
	    SEGSEL_KERN_CODE, timer_int_handler, 0);

    // GPF and page fault
    SETGATE(interrupt_descriptors[INT_GPF], 0,
	    SEGSEL_KERN_CODE, gpf_int_handler, 0);
    SETGATE(interrupt_descriptors[INT_PAGEFAULT], 0,
	    SEGSEL_KERN_CODE, pagefault_int_handler, 0);

    // System calls get special handling.
    // Note that the last argument is '3'.  This means that unprivileged
    // (level-3) applications may generate these interrupts.
    for (int i = INT_SYS; i < INT_SYS + 16; ++i)
	SETGATE(interrupt_descriptors[i], 0,
		SEGSEL_KERN_CODE, sys_int_handlers[i - INT_SYS], 3);

    // Reload segment pointers
    asm volatile("lgdt %0\n\t"
		 "ltr %1\n\t"
		 "lidt %2"
		 :
		 : "m" (global_descriptor_table),
		   "r" ((uint16_t) SEGSEL_TASKSTATE),
		   "m" (interrupt_descriptor_table));
}


// interrupt_init
//    Set up the interrupt controller (Intel part number 8259A).
//
//    Each interrupt controller supports up to 8 different kinds of interrupt.
//    The first x86s supported only one controller; this was too few, so modern
//    x86 machines can have more than one controller, a master and some slaves.
//    Much hoop-jumping is required to get the controllers to communicate!
//
//    Note: "IRQ" stands for "Interrupt ReQuest line", and stands for an
//    interrupt number.

#define MAX_IRQS	16	// Number of IRQs

// I/O Addresses of the two 8259A programmable interrupt controllers
#define IO_PIC1		0x20	// Master (IRQs 0-7)
#define IO_PIC2		0xA0	// Slave (IRQs 8-15)

#define IRQ_SLAVE	2	// IRQ at which slave connects to master

// Timer-related constants
#define	IO_TIMER1	0x040		/* 8253 Timer #1 */
#define	TIMER_MODE	(IO_TIMER1 + 3)	/* timer mode port */
#define	  TIMER_SEL0	0x00		/* select counter 0 */
#define	  TIMER_RATEGEN	0x04		/* mode 2, rate generator */
#define   TIMER_16BIT	0x30		/* r/w counter 16 bits, LSB first */

// Timer frequency: (TIMER_FREQ/freq) generates a frequency of 'freq' Hz.
#define	TIMER_FREQ	1193182
#define TIMER_DIV(x)	((TIMER_FREQ+(x)/2)/(x))

static uint16_t interrupts_enabled;

static void interrupt_mask(void) {
    uint16_t masked = ~interrupts_enabled;
    outb(IO_PIC1+1, masked & 0xFF);
    outb(IO_PIC2+1, (masked >> 8) & 0xFF);
}

void interrupt_init(void) {
    // mask all interrupts
    interrupts_enabled = 0;
    interrupt_mask();

    /* Set up master (8259A-1) */
    // ICW1:  0001g0hi
    //    g:  0 = edge triggering (1 = level triggering)
    //    h:  0 = cascaded PICs (1 = master only)
    //    i:  1 = ICW4 required (0 = no ICW4)
    outb(IO_PIC1, 0x11);

    // ICW2:  Trap offset. Interrupt 0 will cause trap INT_HARDWARE.
    outb(IO_PIC1+1, INT_HARDWARE);

    // ICW3:  On master PIC, bit mask of IR lines connected to slave PICs;
    //        on slave PIC, IR line at which slave connects to master (0-8)
    outb(IO_PIC1+1, 1<<IRQ_SLAVE);

    // ICW4:  000nbmap
    //    n:  1 = special fully nested mode
    //    b:  1 = buffered mode
    //    m:  0 = slave PIC, 1 = master PIC
    //	  (ignored when b is 0, as the master/slave role
    //	  can be hardwired).
    //    a:  1 = Automatic EOI mode
    //    p:  0 = MCS-80/85 mode, 1 = intel x86 mode
    outb(IO_PIC1+1, 0x3);

    /* Set up slave (8259A-2) */
    outb(IO_PIC2, 0x11);			// ICW1
    outb(IO_PIC2+1, INT_HARDWARE + 8);	// ICW2
    outb(IO_PIC2+1, IRQ_SLAVE);		// ICW3
    // NB Automatic EOI mode doesn't tend to work on the slave.
    // Linux source code says it's "to be investigated".
    outb(IO_PIC2+1, 0x01);			// ICW4

    // OCW3:  0ef01prs
    //   ef:  0x = NOP, 10 = clear specific mask, 11 = set specific mask
    //    p:  0 = no polling, 1 = polling mode
    //   rs:  0x = NOP, 10 = read IRR, 11 = read ISR
    outb(IO_PIC1, 0x68);             /* clear specific mask */
    outb(IO_PIC1, 0x0a);             /* read IRR by default */

    outb(IO_PIC2, 0x68);               /* OCW3 */
    outb(IO_PIC2, 0x0a);               /* OCW3 */

    // re-disable interrupts
    interrupt_mask();
}


// timer_init(rate)
//    Set the timer interrupt to fire `rate` times a second. Disables the
//    timer interrupt if `rate <= 0`.

void timer_init(int rate) {
    if (rate > 0) {
	outb(TIMER_MODE, TIMER_SEL0 | TIMER_RATEGEN | TIMER_16BIT);
	outb(IO_TIMER1, TIMER_DIV(rate) % 256);
	outb(IO_TIMER1, TIMER_DIV(rate) / 256);
	interrupts_enabled |= 1 << (INT_TIMER - INT_HARDWARE);
    } else
	interrupts_enabled &= ~(1 << (INT_TIMER - INT_HARDWARE));
    interrupt_mask();
}


// virtual_memory_init
//    Initialize the virtual memory system, including an initial page
//    directory `kernel_pagedir`.

pageentry_t kernel_pagedir[PAGETABLE_NENTRIES] __attribute__((aligned(PAGESIZE)));
static pageentry_t kernel_pagetable0[PAGETABLE_NENTRIES] __attribute__((aligned(PAGESIZE)));

void virtual_memory_init(void) {
    memset(kernel_pagedir, 0, sizeof(pageentry_t) * PAGETABLE_NENTRIES);
    kernel_pagedir[0] = (uintptr_t) kernel_pagetable0 | PTE_P | PTE_W | PTE_U;

    virtual_memory_map(kernel_pagedir, (uintptr_t) 0, (uintptr_t) 0,
		       MEMSIZE_PHYSICAL, PTE_P | PTE_W | PTE_U);

    // Use special instructions to initialize paged virtual memory.
    lcr3(kernel_pagedir);
    uint32_t cr0 = rcr0();
    cr0 |= CR0_PE | CR0_PG | CR0_AM | CR0_WP | CR0_NE | CR0_TS
	| CR0_EM | CR0_MP;
    cr0 &= ~(CR0_TS | CR0_EM);
    lcr0(cr0);
}


// virtual_memory_map(pagedir, va, pa, sz, perm)
//    Change the mappings for virtual address range `[va, va+sz)` in
//    kernel page directory `pagedir`.
//
//    Virtual address `va + X` maps to physical address `pa + X` for all
//    `X >= 0 && X < sz`. The mapping has permission bits `perm`.
//
//    `va`, `pa`, and `sz` must be multiples of PAGESIZE (4096). `perm`
//    should be a combination of `PTE_P` (the memory is Present), `PTE_W`
//    (the memory is Writable), and `PTE_U` (the memory may be accessed by
//    User applications).

void virtual_memory_map(pageentry_t *pagedir, uintptr_t va, uintptr_t pa,
			size_t sz, int perm) {
    assert(va % PAGESIZE == 0 && pa % PAGESIZE == 0 && sz % PAGESIZE == 0);
    assert(va + sz >= va && pa + sz >= pa);
    assert(perm >= 0 && perm < 0x1000);

    int pagetable_index = -1;
    pageentry_t *pagetable = 0;
    for (; sz != 0; va += PAGESIZE, pa += PAGESIZE, sz -= PAGESIZE) {
	if ((va >> 22) != pagetable_index) {
	    pagetable_index = (va >> 22);
	    pageentry_t ptaddr = pagedir[pagetable_index];

	    // check that we can write this page table
	    assert((ptaddr & PTE_P) && (pagedir[ptaddr >> 22] & PTE_P));
	    pagetable = (pageentry_t *) PTE_ADDR(ptaddr);
	   
	}
	pagetable[(va >> 12) & 0x3FF] = pa | perm;
    }
}


// virtual_memory_lookup(pagedir, va)
//    Return the page entry corresponding to virtual address `va` in page
//    directory `pagedir`. Returns 0 if `va` is not mapped; otherwise,
//    returns some `pte`.
//
//    To extract the physical address of the mapped page, use `PTE_ADDR(pte)`.
//    To extract flags, use `(pte & PTE_U)` and `(pte & PTE_W)`.

pageentry_t virtual_memory_lookup(pageentry_t *pagedir, uintptr_t va) {
    pageentry_t ptaddr = pagedir[va >> 22];
    if (ptaddr & PTE_P) {
	pageentry_t *pagetable = (pageentry_t *) PTE_ADDR(ptaddr);
	ptaddr = pagetable[(va >> 12) & 0x3FF] & (ptaddr | ~(PTE_W | PTE_U));
    }
    if (ptaddr & PTE_P)
	return ptaddr;
    else
	return 0;
}


// physical_memory_isreserved(pa)
//    Returns non-zero iff `pa` is a reserved physical address.

#define IOPHYSMEM	0x000A0000
#define EXTPHYSMEM	0x00100000

int physical_memory_isreserved(uintptr_t pa) {
    return pa == 0 || (pa >= IOPHYSMEM && pa < EXTPHYSMEM);
}


// poweroff
//    Turn off the virtual machine. (QEMU specific)

void poweroff(void) {
    for (const char *s = "Shutdown"; *s; ++s)
	outb(0x8900, *s);
 loop: goto loop;
}


// reboot
//    Reboot the virtual machine.

void reboot(void) {
    outb(0x92, 3);
 loop: goto loop;
}


// process_init(p, flags)
//    Initialize special-purpose registers for process `p`.

void process_init(proc *p, int flags) {
    memset(&p->p_registers, 0, sizeof(p->p_registers));
    p->p_registers.reg_cs = SEGSEL_APP_CODE | 3;
    p->p_registers.reg_ds = SEGSEL_APP_DATA | 3;
    p->p_registers.reg_es = SEGSEL_APP_DATA | 3;
    p->p_registers.reg_ss = SEGSEL_APP_DATA | 3;
    p->p_registers.reg_eflags = EFLAGS_IF;

    if (flags & PROCINIT_ALLOW_PROGRAMMED_IO)
	p->p_registers.reg_eflags |= EFLAGS_IOPL_3;
    if (flags & PROCINIT_DISABLE_INTERRUPTS)
	p->p_registers.reg_eflags &= ~EFLAGS_IF;
}


// console_show_cursor(cpos)
//    Move the console cursor to position `cpos`, which should be between 0
//    and 80 * 25.

void console_show_cursor(int cpos) {
    if (cpos < 0 || cpos > CONSOLE_ROWS * CONSOLE_COLUMNS)
	cpos = 0;
    outb(0x3D4, 14);
    outb(0x3D5, cpos / 256);
    outb(0x3D4, 15);
    outb(0x3D5, cpos % 256);
}



// keyboard_readc
//    Read a character from the keyboard. Returns -1 if there is no character
//    to read, and 0 if no real key press was registered but you should call
//    keyboard_readc() again (e.g. the user pressed a SHIFT key). Otherwise
//    returns either an ASCII character code or one of the special characters
//    listed in kernel.h.

// Unfortunately mapping PC key codes to ASCII takes a lot of work.

#define MOD_SHIFT	(1 << 0)
#define MOD_CONTROL	(1 << 1)
#define MOD_CAPSLOCK	(1 << 3)

#define KEY_SHIFT	0372
#define KEY_CONTROL	0373
#define KEY_ALT		0374
#define KEY_CAPSLOCK	0375
#define KEY_NUMLOCK	0376
#define KEY_SCROLLLOCK	0377

#define CKEY(cn)	0x80 + cn

static const uint8_t keymap[256] = {
    /*0x00*/ 0, 033, CKEY(0), CKEY(1), CKEY(2), CKEY(3), CKEY(4), CKEY(5),
	CKEY(6), CKEY(7), CKEY(8), CKEY(9), CKEY(10), CKEY(11), '\b', '\t',
    /*0x10*/ 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i',
	'o', 'p', CKEY(12), CKEY(13), CKEY(14), KEY_CONTROL, 'a', 's',
    /*0x20*/ 'd', 'f', 'g', 'h', 'j', 'k', 'l', CKEY(15),
	CKEY(16), CKEY(17), KEY_SHIFT, CKEY(18), 'z', 'x', 'c', 'v',
    /*0x30*/ 'b', 'n', 'm', CKEY(19), CKEY(20), CKEY(21), KEY_SHIFT, '*',
	KEY_ALT, ' ', KEY_CAPSLOCK, 0, 0, 0, 0, 0,
    /*0x40*/ 0, 0, 0, 0, 0, KEY_NUMLOCK, KEY_SCROLLLOCK, '7',
	'8', '9', '-', '4', '5', '6', '+', '1',
    /*0x50*/ '2', '3', '0', '.', 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0,
    /*0x60*/ 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0,
    /*0x70*/ 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0,
    /*0x80*/ 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0,
    /*0x90*/ 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, CKEY(14), KEY_CONTROL, 0, 0,
    /*0xA0*/ 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0,
    /*0xB0*/ 0, 0, 0, 0, 0, '/', 0, 0,  KEY_ALT, 0, 0, 0, 0, 0, 0, 0,
    /*0xC0*/ 0, 0, 0, 0, 0, 0, 0, KEY_HOME,
	KEY_UP, KEY_PAGEUP, 0, KEY_LEFT, 0, KEY_RIGHT, 0, KEY_END,
    /*0xD0*/ KEY_DOWN, KEY_PAGEDOWN, KEY_INSERT, KEY_DELETE, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0,
    /*0xE0*/ 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0,
    /*0xF0*/ 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0
};

static const struct keyboard_key {
    uint8_t map[4];
} complex_keymap[] = {
    /*CKEY(0)*/ {{'1', '!', 0, 0}},  /*CKEY(1)*/ {{'2', '@', 0, 0}},
    /*CKEY(2)*/ {{'3', '#', 0, 0}},  /*CKEY(3)*/ {{'4', '$', 0, 0}},
    /*CKEY(4)*/ {{'5', '%', 0, 0}},  /*CKEY(5)*/ {{'6', '^', 0, 036}},
    /*CKEY(6)*/ {{'7', '&', 0, 0}},  /*CKEY(7)*/ {{'8', '*', 0, 0}},
    /*CKEY(8)*/ {{'9', '(', 0, 0}},  /*CKEY(9)*/ {{'0', ')', 0, 0}},
    /*CKEY(10)*/ {{'-', '_', 0, 037}},  /*CKEY(11)*/ {{'=', '+', 0, 0}},
    /*CKEY(12)*/ {{'[', '{', 033, 0}},  /*CKEY(13)*/ {{']', '}', 035, 0}},
    /*CKEY(14)*/ {{'\n', '\n', '\r', '\r'}},
    /*CKEY(15)*/ {{';', ':', 0, 0}},
    /*CKEY(16)*/ {{'\'', '"', 0, 0}},  /*CKEY(17)*/ {{'`', '~', 0, 0}},
    /*CKEY(18)*/ {{'\\', '|', 034, 0}},  /*CKEY(19)*/ {{',', '<', 0, 0}},
    /*CKEY(20)*/ {{'.', '>', 0, 0}},  /*CKEY(21)*/ {{'/', '?', 0, 0}}
};

int keyboard_readc(void) {
    static uint8_t modifiers;
    static uint8_t last_escape;

    if ((inb(KEYBOARD_STATUSREG) & KEYBOARD_STATUS_READY) == 0)
	return -1;

    uint8_t data = inb(KEYBOARD_DATAREG);
    uint8_t escape = last_escape;
    last_escape = 0;

    if (data == 0xE0) {		// mode shift
	last_escape = 0x80;
	return 0;
    } else if (data & 0x80) {	// key release: matters only for modifier keys
	int ch = keymap[(data & 0x7F) | escape];
	if (ch >= KEY_SHIFT && ch < KEY_CAPSLOCK)
	    modifiers &= ~(1 << (ch - KEY_SHIFT));
	return 0;
    }

    int ch = (unsigned char) keymap[data | escape];

    if (ch >= 'a' && ch <= 'z') {
	if (modifiers & MOD_CONTROL)
	    ch -= 0x60;
	else if (!(modifiers & MOD_SHIFT) != !(modifiers & MOD_CAPSLOCK))
	    ch -= 0x20;
    } else if (ch >= KEY_CAPSLOCK) {
	modifiers ^= 1 << (ch - KEY_SHIFT);
	ch = 0;
    } else if (ch >= KEY_SHIFT) {
	modifiers |= 1 << (ch - KEY_SHIFT);
	ch = 0;
    } else if (ch >= CKEY(0) && ch <= CKEY(21))
	ch = complex_keymap[ch - CKEY(0)].map[modifiers & 3];
    else if (ch < 0x80 && (modifiers & MOD_CONTROL))
	ch = 0;

    return ch;
}


// log_printf, log_vprintf
//    Print debugging messages to the host's `log.txt` file. We run QEMU
//    so that messages written to the QEMU "parallel port" end up in `log.txt`.

#define IO_PARALLEL1_DATA	0x378
#define IO_PARALLEL1_STATUS	0x379
# define IO_PARALLEL_STATUS_BUSY	0x80
#define IO_PARALLEL1_CONTROL	0x37A
# define IO_PARALLEL_CONTROL_SELECT	0x08
# define IO_PARALLEL_CONTROL_INIT	0x04
# define IO_PARALLEL_CONTROL_STROBE	0x01

static void delay(void) {
    (void) inb(0x84);
    (void) inb(0x84);
    (void) inb(0x84);
    (void) inb(0x84);
}

static void parallel_port_putc(struct printer *p, unsigned char c, int color) {
    static int initialized;
    (void) p, (void) color;
    if (!initialized) {
	outb(IO_PARALLEL1_CONTROL, 0);
	initialized = 1;
    }

    for (int i = 0;
	 i < 12800 && (inb(IO_PARALLEL1_STATUS) & IO_PARALLEL_STATUS_BUSY) == 0;
	 ++i)
	delay();
    outb(IO_PARALLEL1_DATA, c);
    outb(IO_PARALLEL1_CONTROL, IO_PARALLEL_CONTROL_SELECT
	 | IO_PARALLEL_CONTROL_INIT | IO_PARALLEL_CONTROL_STROBE);
    outb(IO_PARALLEL1_CONTROL, IO_PARALLEL_CONTROL_SELECT
	 | IO_PARALLEL_CONTROL_INIT);
}

void log_vprintf(const char *format, va_list val) {
    struct printer p;
    p.putc = parallel_port_putc;
    printer_vprintf(&p, 0, format, val);
}

void log_printf(const char *format, ...) {
    va_list val;
    va_start(val, format);
    log_vprintf(format, val);
    va_end(val);
}


// check_keyboard
//    Check for the user typing a control key. 'a', 'f', and 'e' cause a soft
//    reboot where the kernel runs the allocator programs, "fork", or
//    "forkexit", respectively. Control-C or 'q' exit the virtual machine.

void check_keyboard(void) {
    int c = keyboard_readc();
    if (c == 'a' || c == 'f' || c == 'e') {
	uint32_t multiboot_info[5];
	multiboot_info[0] = 4;
	multiboot_info[4] = (uint32_t) (c == 'a' ? "allocator"
					: (c == 'e' ? "forkexit" : "fork"));
	asm volatile("movl $0x2BADB002, %%eax; jmp multiboot_start"
		     : : "b" (multiboot_info) : "memory");
    } else if (c == 0x03 || c == 'q')
	poweroff();
}


// fail
//    Loop until user presses Control-C, then poweroff.

static void fail(void) __attribute__((noreturn));
static void fail(void) {
    while (1)
	check_keyboard();
}


// panic, assert_fail
//    Use console_printf() to print a failure message and then wait for
//    control-C. Also write the failure message to the log.

void panic(const char *format, ...) {
    va_list val;
    va_start(val, format);

    // Print panic message to both the screen and the log
    int cpos = console_printf(CPOS(23, 0), 0xC000, "PANIC: ");
    log_printf("PANIC: ");

    cpos = console_vprintf(cpos, 0xC000, format, val);
    log_vprintf(format, val);

    if (CCOL(cpos)) {
	cpos = console_printf(cpos, 0xC000, "\n");
	log_printf("\n");
    }

    va_end(val);
    fail();
}

void assert_fail(const char *file, int line, const char *msg) {
    panic("%s:%d: assertion '%s' failed\n", file, line, msg);
}
