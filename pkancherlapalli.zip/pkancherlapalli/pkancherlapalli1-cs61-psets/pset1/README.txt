README for CS 61 Problem Set 1
------------------------------
YOU MUST FILL OUT THIS FILE BEFORE SUBMITTING!

YOUR NAME:PavanKumar Kancherlapalli	
YOUR HUID:20851244

(Optional, for partner)
YOUR NAME:Michael Michailidis
YOUR HUID:30825047

OTHER COLLABORATORS AND CITATIONS (if any):

Michael and myself have partenered for the project.

NOTES FOR THE GRADER (if any):



EXTRA CREDIT ATTEMPTED (if any):
