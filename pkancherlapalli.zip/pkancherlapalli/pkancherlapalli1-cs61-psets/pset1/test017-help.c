#include "m61.h"

void my_free(void *ptr) {
    free(ptr);
}
