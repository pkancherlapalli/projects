#define M61_DISABLE 1
#include "m61.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <inttypes.h>

//metadata definition
struct header
{
  void* ptr;  
  size_t sz; 
  int  freed_line;
  char* freed_file;
  int isactive;
  size_t magic;
  char* alloc_file;
  int alloc_line;
  struct header* prev;
  struct header* next;
};

struct footer
{
  size_t magic ;
  //size_t sz;
};

struct hhlist
{
  char* file;
  int line;
  unsigned long long count;
  unsigned long long sz;
};

struct hhcounter
{
  long long incr;
  struct hhlist list;
};

struct hhsize
{
  long long  incrsz;
  long long decrsz;
  struct hhlist list;
};

#define MAGIC 0x123890AB //to check integrity of writes
#define hdr_size sizeof(struct header)
#define ftr_size sizeof(struct footer)

//statics for tracking total and active allocations
static unsigned long long tot_alloc=0;
static unsigned long long tot_size=0;
static unsigned long long active_count =0;
static unsigned long long active_size =0;
static unsigned long long fail_count =0;
static unsigned long long fail_size = 0;

//doubly linked list that holds all active allocations
static struct header* table = NULL;  

//utility functions to maintain active allocations
void m61_removetableentry(void* ptr);
void* m61_gettableentry(void* ptr);
int m61_hastableentry(void* ptr);

//statics for heavy hitters
//static struct hhlist* hh;
//static size_t hhsize;
//static size_t hh_capacity;

static struct hhcounter* cc;
static struct hhsize* ss;
static int cc_capacity;
static int cc_size;
static int ss_size;

//utility function to maintain counters for heavy hitters
void m61_enlargehhlist(void);
int m61_findinhhcounter(int line);
int m61_findinhhsize(int line, size_t sz);


void *m61_malloc(size_t sz, const char *file, int line)
{
  (void) file, (void) line;
  // avoid uninitialized variable warnings
  // Your code here.  
  struct header* hdr;
  struct footer* ftr;
  size_t allocsz = 0 ;
  
  void* ptr;
  
  allocsz = hdr_size + ftr_size + sz;
  //overflow condition
  if(allocsz < sz){
    fail_count = fail_count +1;
    fail_size = fail_size + sz;
    return NULL;
  }

  // if (hhsize == hh_capacity)
  if(cc_capacity == 0)
      m61_enlargehhlist();

  hdr = (struct header*) malloc(allocsz);
    
  if(hdr  == NULL) 
  { 
    fail_count = fail_count +1;
    fail_size = fail_size + sz;
    return NULL;
  }

  hdr->ptr = NULL;
  hdr->sz = 0;
  hdr->magic = MAGIC;
  hdr->freed_line = 0;

  ptr = (void*)(hdr + 1);
  ftr = (struct footer*)(ptr + sz);
  hdr->ptr = ptr;
  hdr->sz =  sz;
  hdr->isactive = 1;
  hdr->alloc_file = (char*)&file[0];
  hdr->alloc_line = line;
  ftr->magic = MAGIC;
  
  if(table == NULL){
    hdr->prev = table;
    hdr->next = table;
    table = hdr;
  }
  else{
    hdr->next = table->next;
    table->next = hdr;
    hdr->prev = table;
    table = hdr;
  }
  
  int ccindex = m61_findinhhcounter(line);
  if(ccindex != -1)
  {
    cc[ccindex].list.file = (char*)&file[0];
    cc[ccindex].list.line = line;
    cc[ccindex].list.sz += sz;
    cc[ccindex].list.count +=1;
    
  }
  int szindex =  m61_findinhhsize(line,sz);
  if(szindex != -1)
    {
      ss[szindex].list.file = (char*)&file[0];
      ss[szindex].list.line = line;
      ss[szindex].list.sz += sz;
      ss[szindex].list.count += 1;
    }
  // if(index != -1)
  // {
  //  hh[index].sz += sz;
  //  hh[index].count += 1;
  // }
  //else
  //{
  //   hh[hhsize].file = (char*)&file[0];
  //   hh[hhsize].line = line;
  //   hh[hhsize].sz += sz;
  //   hh[hhsize].count++;
  //   hhsize++;
  // }
   
  tot_alloc = tot_alloc + 1;
  tot_size = tot_size + sz;
  active_count = active_count + 1;
  active_size = active_size + sz;
  return ptr;
}

void m61_free(void *ptr, const char *file, int line) {
  (void) file, (void) line;	// avoid uninitialized variable warnings
  // Your code here.

  if(!ptr)
    return;

  int ncheck =0;
  if((int*)ptr > (int*)(&ncheck)){
    printf("MEMORY BUG : %s:%d: invalid free of pointer %p, not in heap\n",
	   file,line,ptr);
    return;
  }

  struct header* hdr =(struct header*)(ptr-hdr_size);
  
  
  if((int*)hdr > (int*)ptr){
    printf("MEMORY BUG : %s:%d: invalid free of pointer %p, not in heap\n",
	   file,line,ptr);
    return;
  }
 
  if(hdr->freed_line > 0)
    {
      printf("MEMORY BUG: %s:%d: double free of pointer \n  %s:%d: pointer %p previously freed here\n ", file,line,hdr->freed_file,hdr->freed_line,ptr);
      return;
    }  

  if(hdr->ptr != ptr)
  { 
    hdr = (struct header*)m61_gettableentry(ptr); 
    if(hdr != NULL){
      int n = ptr - hdr->ptr;
      printf("MEMORY BUG: %s:%d: invalid free of pointer %p, not allocated\n  %s:%d: %p is %d bytes inside a %d byte region allocated here\n",
	     file,line,ptr,hdr->alloc_file,hdr->alloc_line,ptr,n,hdr->sz);
    }
    else{
      printf("MEMORY BUG: %s:%d: invalid free of pointer %p, not allocated\n",file,line,ptr);
    }
    return; 
  }
  
  struct footer* ftr = (struct footer*)(ptr + hdr->sz);
  
  if(ftr->magic != hdr->magic)
  {
    printf("MEMORY BUG : detected wild write during free of pointer %p\n",ptr);
    abort();
  }
  if(m61_hastableentry(hdr) == 0)
  {
    printf("MEMORY BUG :  free of pointer %p\n",ptr);
    hdr->isactive = 0;
    return;
  }
  if(hdr->ptr == ptr)
  {
   active_size = active_size - hdr->sz;
   active_count = active_count -1;
 
   hdr->isactive = 0;
   hdr->freed_line = line;
   hdr->freed_file = (char*)&file[0]; 
   m61_removetableentry(hdr); 
   free(hdr);
  }
  
    
}

void *m61_realloc(void *ptr, size_t sz, const char *file, int line) {
    (void) file, (void) line;	// avoid uninitialized variable warnings
    // Your code here.

    void *new_ptr = NULL;
     if (sz != 0)
       new_ptr = m61_malloc(sz,file,line);
     if (ptr != NULL && new_ptr != NULL) {
         struct header *hdr =(struct header*)(ptr - hdr_size);
         size_t old_sz = hdr->sz;
         if (old_sz < sz)
             memcpy(new_ptr, ptr, old_sz);
         else
             memcpy(new_ptr, ptr, sz);
     }
     m61_free(ptr,file,line);
     return new_ptr;
    
}

void *m61_calloc(size_t nmemb, size_t sz, const char *file, int line) {
    (void) file, (void) line;	// avoid uninitialized variable warnings
    // Your code here.
    
    //overflow
    if(nmemb >  nmemb*sz){
      fail_count = fail_count +1;
      fail_size = fail_size + sz;
      return NULL;    
    }    

    void *ptr = m61_malloc(sz * nmemb,file,line);
     if (ptr != NULL)
         memset(ptr, 0, sz * nmemb);     // clear memory to 0
     return ptr;

}

void m61_getstatistics(struct m61_statistics *stats) {
    // Stub: set all statistics to 0
    memset(stats, 0, sizeof(struct m61_statistics));
    // Your code here.
    stats->total_count = tot_alloc;
    stats->total_size = tot_size;
    stats->active_count = active_count;
    stats->active_size = active_size;
    stats->fail_count = fail_count;
    stats->fail_size = fail_size;

}

void m61_printstatistics(void) {
    struct m61_statistics stats;
    m61_getstatistics(&stats);

    printf("malloc count: active %10llu   total %10llu   fail %10llu\n\
malloc size:  active %10llu   total %10llu   fail %10llu\n",
	   stats.active_count, stats.total_count, stats.fail_count,
	   stats.active_size, stats.total_size, stats.fail_size);
}

void m61_printleakreport(void) {
    // Your code here.
  struct header* p = table;
  while(p && p->magic == MAGIC)
  {
    if(p->isactive == 1)
    {
      printf("LEAK CHECK: %s:%d: allocated object %p with size %d\n",p->alloc_file, p->alloc_line, p->ptr,p->sz);
    }
    p = p->prev;
  }

}

void  m61_removetableentry(void* ptr)
{
  struct header *p = table;
  struct header* next = NULL;
  while(p && p->magic == MAGIC)
  {
     if((struct header*)ptr == p)
     {
       if(next != NULL && next->prev == p)
	 next->prev = p->prev;
       if(p->prev != NULL && p->prev->next == p)
	 p->prev->next = p->next; 
       break;
     }
     next = p;
     p = p->prev;
     
  }
  return ;
}

int m61_hastableentry(void* ptr)
{
  struct header* p = table;
  while(p && p->magic == MAGIC)
  {
    if((struct header*)ptr == p)
      {
        if(p->prev == NULL && p->next == NULL)
	  return 1;
        if(p->prev == NULL && p->next->prev == p)
          return 1;
        if(p->prev != NULL && p == p->prev->next)
           return 1;
      }
    p = p->prev;
  }
  return 0;
}

void* m61_gettableentry(void* ptr)
{
   struct header* p = table;
   while(p && p->magic == MAGIC)
   {
     uintptr_t xx =(uintptr_t)p;
     uintptr_t yy= (uintptr_t)ptr;
     uintptr_t z= (uintptr_t)(p+1);
     uintptr_t zz = (uintptr_t)(z+p->sz);
     if(xx < yy  && yy < zz){
       return p;
       break;
     }
     p = p->prev;
   }
   return NULL;
}

void m61_printheavyhitterreport(void)
{
  float countratio =0.0;
  float sizeratio =0.0;
  for(size_t i=0; i<cc_capacity; i++)
  {
    countratio =100*((float)cc[i].incr)/tot_alloc;
    sizeratio =100*((float)ss[i].incrsz)/tot_size;

    // if(countratio > 20)
      {
	printf("HEAVY HITTER: %s:%d: %llu count (~%.2f%%)\n",cc[i].list.file,cc[i].list.line,cc[i].incr,countratio);
    
      }
    // if( sizeratio > 20)
      {
	printf("HEAVY HITTER: %s:%d: %llu bytes (~%.2f%%)\n",ss[i].list.file,ss[i].list.line,ss[i].incrsz,sizeratio);
      }
      
   } 

  //for(int i=0;i<cc_capacity; i++)
  //{
    // countratio =100*((double)(cc[i].incr)/tot_alloc);
  // printf("HEAVY HITTER: %s:%d: %llu count\n",cc[i].list.file,cc[i].list.line,cc[i].incr);//,countratio);
  // }
}

void m61_enlargehhlist(void)
{
  // hh_capacity = hh_capacity ? hh_capacity*2 : 100;
  // hh = realloc(hh,hh_capacity*sizeof(struct hhlist));

  //cc_capacity = k = 4. as we want 25% or more frequent elements.
  cc_capacity= cc_capacity ? cc_capacity*2 : 4; 
  cc = realloc(cc, cc_capacity*sizeof(struct hhcounter));
  ss = realloc(ss, cc_capacity*sizeof(struct hhsize));
  ss_size =0;
  cc_size =0;
}

int m61_findinhhcounter(int line)
{

  int nzeroindex = -1;
  int ncounterindex= -1;
  
  printf("\n\n");
  for(int i=0; i< cc_size; i++)
  {
    //printf("%d\t%d\t%d\t%llu\n", i,line, cc[i].list.line,cc[i].incr);
    if(cc[i].list.line == line)
    {
      cc[i].incr++;
      ncounterindex =i;
    }
 
  }
  if(ncounterindex != -1)
     return ncounterindex;

  if(cc_size < cc_capacity)
  {
      cc[cc_size].incr++;
      cc_size++;
      return cc_size-1;
  }

  if(cc_size == cc_capacity )
  {
    for(int i=0; i< cc_size; i++)
    {     
      if(cc[i].incr ==0 )
	{
	nzeroindex =i;
	break;
	}
    }
   
  }

  if(nzeroindex != -1)
  {
    cc[nzeroindex].incr++;
    return nzeroindex;
  }
  
  for(int i=0; i< cc_size; i++)
  {
   
    cc[i].incr--;

    if(cc[i].incr == 0){
      cc[i].list.count =0;
      cc[i].list.sz =0;
    }
  }

  return -1;

  //for(size_t i =0; i< hhsize;i++)
  // {
  //   if(hh[i].line == line)
  //      return i;
  //}
  //return -1;
}

int m61_findinhhsize(int line, size_t sz)
{
   int nzeroindex = -1;
   int ncounterindex= -1;
  
   printf("\n\n");
   for(int i=0; i< ss_size; i++)
   {
     printf("%d\t%d\t%d\t%llu\t%llu\n", i,line,ss[i].list.line,ss[i].incrsz ,ss[i].list.sz);
     if(ss[i].list.line == line)
     {
      ss[i].incrsz = ss[i].incrsz + sz;
      ncounterindex =i;
     }
   }

   if(ncounterindex != -1)
     return ncounterindex;

   if(ss_size < cc_capacity)
   {
      ss[ss_size].incrsz += sz;
      ss_size++;
      return ss_size-1;
   }

   if(ss_size == cc_capacity )
   {
     for(int i=0; i< ss_size; i++)
     {     
        if(ss[i].incrsz ==0 )
	{
	 nzeroindex =i;
	 break;
	}
      }
   
   }

   if(nzeroindex != -1)
   {
    ss[nzeroindex].incrsz += sz;
    return nzeroindex;
   }
  
   for(int i=0; i<ss_size; i++)
   {
   
     ss[i].decrsz += sz;

     if(ss[i].decrsz > ss[i].incrsz && nzeroindex == -1)
     {
        ss[i].decrsz =0;
        ss[i].list.sz = 0;
        ss[i].incrsz =sz;
        nzeroindex =i;   
     }
   }
   return nzeroindex;
}
