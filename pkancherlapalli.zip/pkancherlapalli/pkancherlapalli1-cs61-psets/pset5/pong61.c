#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <assert.h>
#include "serverinfo.h"
#include <pthread.h>

static const char *pong_host = PONG_HOST;
static const char *pong_port = PONG_PORT;
static const char *pong_user = PONG_USER;


// Timer and interrupt functions (defined and explained below)

double timestamp(void);
void sleep_for(double delay);
void interrupt_after(double delay);
void interrupt_cancel(void);


// HTTP connection management functions

// http_connection
//    This object represents an open HTTP connection to a server.
typedef struct http_connection {
    int fd;                 // Socket file descriptor

    int state;              // Response parsing status (see below)
    int status_code;        // Response status code (e.g., 200, 402)
    size_t content_length;  // Content-Length value
    int has_content_length; // 1 iff Content-Length was provided

  // char buf[BUFSIZ];       // Response buffer
    char* buf;
    size_t len;             // Length of response buffer
} http_connection;

//structure for holding connections
struct connection_table {
  http_connection* conn;
  struct connection_table* prev;
  struct connection_table* next;
};

//head of linked list for caching connections
static struct connection_table*  table;
static int cache_size;
static double request_delay;// store stop request time
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
//static pthread_cond_t count_threshold_cv;

static void add_connentry(void* conn);
static void remove_connentry(void* conn);
//static void* remove_connentries();
static void* http_getbody(void*);
void set_delay(double);
void clean(void);

// `http_connection::state` constants:
#define HTTP_REQUEST 0      // Request not sent yet
#define HTTP_INITIAL 1      // Before first line of response
#define HTTP_HEADERS 2      // After first line of response, in headers
#define HTTP_BODY    3      // In body
#define HTTP_DONE    (-1)   // Body complete, available for a new request
#define HTTP_CLOSED  (-2)   // Body complete, connection closed
#define HTTP_BROKEN  (-3)   // Parse error

// helper functions
char *http_truncate_response(http_connection *conn);
static int http_consume_headers(http_connection *conn, int eof);

static void usage(void);


// http_connect(ai)
//    Open a new connection to the server described by `ai`. Returns a new
//    `http_connection` object for that server connection. Exits with an
//    error message if the connection fails.
http_connection *http_connect(const struct addrinfo *ai) {
    // connect to the server
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        perror("socket");
        exit(1);
    }

    int yes = 1;
    (void) setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

    int r = connect(fd, ai->ai_addr, ai->ai_addrlen);
    if (r < 0) {
        perror("connect");
        exit(1);
    }

    // construct an http_connection object for this connection
    http_connection *conn = (http_connection *) malloc(sizeof(http_connection));
    conn->fd = fd;
    conn->state = HTTP_REQUEST;
    //conn->incache = 0;
    return conn;
}


// http_close(conn)
//    Close the HTTP connection `conn` and free its resources.
void http_close(http_connection *conn) {
    close(conn->fd);
    free(conn);
}


// http_send_request(conn, uri)
//    Send an HTTP POST request for `uri` to connection `conn`.
//    Exit on error.
void http_send_request(http_connection *conn, const char *uri) {
    assert(conn->state == HTTP_REQUEST || conn->state == HTTP_DONE);

    // prepare and write the request
    char reqbuf[BUFSIZ];
    size_t reqsz = sprintf(reqbuf,
                           "POST /%s/%s HTTP/1.0\r\n"
                           "Host: %s\r\n"
                           "Connection: keep-alive\r\n"
                           "\r\n",
                           pong_user, uri, pong_host);
    size_t pos = 0;
    while (pos < reqsz) {
        ssize_t nw = write(conn->fd, &reqbuf[pos], reqsz - pos);
        if (nw == 0)
            break;
        else if (nw == -1 && errno != EINTR && errno != EAGAIN) {
            perror("write");
            exit(1);
        } else if (nw != -1)
            pos += nw;
    }

    if (pos != reqsz) {
        fprintf(stderr, "connection closed prematurely\n");
        exit(1);
    }

    // clear response information
    conn->state = HTTP_INITIAL;
    conn->status_code = -1;
    conn->content_length = 0;
    conn->has_content_length = 0;
    conn->len = 0;
}


// http_receive_response(conn)
//    Receive a response from the server. On return, `conn->status_code`
//    holds the server's status code, and `conn->buf` holds the response
//    body, which is `conn->len` bytes long and has been null-terminated.
//    If the connection terminated prematurely, `conn->status_code`
//    is -1.
void http_receive_response(http_connection *conn) {
    assert(conn->state != HTTP_REQUEST);
    if (conn->state < 0)
        return;

    // parse connection (http_consume_headers tells us when to stop)
    size_t eof = 0;
    conn->buf = (char*)malloc(BUFSIZ);

    while (http_consume_headers(conn, eof)) {   
      //create thread if response body takes too long
        if(conn->state == HTTP_BODY)
	{
	  pthread_t t;
	  pthread_create(&t,NULL,&http_getbody,conn);
	  break;
	}

	// increase the size of buffer if more has to be read
	if(conn->len != 0 && conn->len + BUFSIZ >=  BUFSIZ){
	  conn->buf[conn->len] =0;
	  conn->buf = (char*)realloc(conn->buf,conn->len + 2*BUFSIZ);  
	}
 
        ssize_t nr = read(conn->fd, &conn->buf[conn->len], BUFSIZ);

        if (nr == 0)
            eof = 1;
        else if (nr == -1 && errno != EINTR && errno != EAGAIN) {
            perror("read");
            exit(1);
        } else if (nr != -1)
            conn->len += nr;
    }

    // null-terminate body
    conn->buf[conn->len] = 0;

    // Status codes >= 500 mean we are overloading the server and should exit.
    if (conn->status_code >= 500) {
        fprintf(stderr, "exiting because of server status %d (%s)\n",
                conn->status_code, http_truncate_response(conn));
        exit(1);
    }
}

static void* http_getbody(void* v){


  pthread_detach(pthread_self());
  http_connection*  conn = (http_connection*)v;

  size_t eof =0;
  while (http_consume_headers(conn, eof)) {
    
     if(conn->len + BUFSIZ >=  BUFSIZ){
	conn->buf[conn->len] =0;
	conn->buf = (char*)realloc(conn->buf,conn->len + 2*BUFSIZ);  
     }

     ssize_t nr = read(conn->fd, &conn->buf[conn->len], BUFSIZ);
     
     if (nr == 0)
          eof = 1;      
     else if (nr == -1 && errno != EINTR && errno != EAGAIN) {
          perror("read");
          exit(1);
     } else if (nr != -1)
          conn->len += nr;
  }
	  
  conn->buf[conn->len] = 0;
  double result = strtod(conn->buf, NULL);
  if (result < 0) {
            fprintf(stderr, "server returned error: %s\n",
                    http_truncate_response(conn));
	    pthread_exit(NULL);
            exit(1);
  }
  if(result > 0 ){
    set_delay(result);
  } 

  //if successful add the connection back to table if not close it.
  if(conn->state == HTTP_DONE )
    add_connentry(conn);
  
  if(conn->state == HTTP_BROKEN || conn->state == HTTP_CLOSED)
    http_close(conn);
   
  pthread_exit(NULL);
  return NULL;
}


// http_truncate_response(conn)
//    Truncate the `conn` response text to a manageable length and return
//    that truncated text. Useful for error messages.
char *http_truncate_response(http_connection *conn) {
    char *eol = strchr(conn->buf, '\n');
    if (eol)
        *eol = 0;
    if (strnlen(conn->buf, 100) >= 100)
        conn->buf[100] = 0;
    return conn->buf;
}


// main(argc, argv)
//    The main loop.
int main(int argc, char **argv) {
    // parse arguments
    int ch;
    while ((ch = getopt(argc, argv, "h:p:u:")) != -1) {
        if (ch == 'h')
            pong_host = optarg;
        else if (ch == 'p')
            pong_port = optarg;
        else if (ch == 'u')
            pong_user = optarg;
        else
            usage();
    }
    if (optind == argc - 1)
        pong_user = argv[optind];
    else if (optind != argc)
        usage();

   

    // look up network address of pong server
    struct addrinfo ai_hints, *ai;
    memset(&ai_hints, 0, sizeof(ai_hints));
    ai_hints.ai_family = AF_INET;
    ai_hints.ai_socktype = SOCK_STREAM;
    ai_hints.ai_flags = AI_NUMERICSERV;
    int r = getaddrinfo(pong_host, pong_port, &ai_hints, &ai);
    if (r != 0) {
        fprintf(stderr, "problem contacting %s: %s\n",
                pong_host, gai_strerror(r));
        exit(1);
    }

    // reset pong board and get its dimensions
    int width, height;
    {
        http_connection *conn = http_connect(ai);
        http_send_request(conn, "reset");
        http_receive_response(conn);
        if (conn->status_code != 200
            || sscanf(conn->buf, "%d %d\n", &width, &height) != 2
            || width <= 0 || height <= 0) {
            fprintf(stderr, "bad response to \"reset\" RPC: %d %s\n",
                    conn->status_code, http_truncate_response(conn));
            exit(1);
        }
        http_close(conn);
    }

    //initialize globals
    cache_size =0;
    table = NULL;
    // print display URL
    printf("Display: http://%s:%s/%s/\n", pong_host, pong_port, pong_user);

    // play game
    int x = 0, y = 0, dx = 1, dy = 1;
    char url[BUFSIZ];
    int k =0;
    request_delay = 0;
  
    //trying to use thread condition wait if cachesize >30
    //pthread_cond_init (&count_threshold_cv, NULL);
    //pthread_t t1;
    //pthread_create(&t1,NULL,&remove_connentries,NULL);

    while (1) {
        http_connection *conn = NULL;
	struct connection_table* t = table;
	while(t){
	  if(t->conn->state == HTTP_DONE){
	    conn = t->conn;
	    remove_connentry(conn);
            break;
	  }	 
	  t= t->prev;
	}
	
        if(conn == NULL)	 
          conn = http_connect(ai);
		      
        sprintf(url, "move?x=%d&y=%d&style=on", x, y);

	//phase 4
        if( request_delay > 0)
	  sleep_for(request_delay);

        http_send_request(conn, url);
	request_delay =0;

        http_receive_response(conn);
        if (conn->status_code != 200){
            fprintf(stderr, "warning: %d,%d: server returned status %d "
                    "(expected 200) \n", x, y, conn->status_code);
	    sleep((2^k) * 0.001);
	    http_close(conn);
	    k=k+1;
	    continue;
	}
	k = 0;

        double result = strtod(conn->buf, NULL);
        if (result < 0) {
            fprintf(stderr, "server returned error: %s\n",
                    http_truncate_response(conn));
            exit(1);
        }

	//phase 4
	if(result > 0){
	  set_delay(result);
	}
	
        x += dx;
        y += dy;
        if (x < 0 || x >= width) {
            dx = -dx;
            x += 2 * dx;
        }
        if (y < 0 || y >= height) {
            dy = -dy;
            y += 2 * dy;
        }

        // wait 0.1sec before moving to next frame
        sleep_for(0.1);
	//add connection back to pool if everything is fine or else close it.
	if(conn->state == HTTP_DONE)
	   add_connentry(conn);
	
	if(conn->state == HTTP_BROKEN || conn->state == HTTP_CLOSED)
	   http_close(conn);
    }

    clean();
    //pthread_join(t1,NULL);
    // pthread_cancel(t1);
    //pthread_cond_destroy(&count_threshold_cv);
    //pthread_exit(NULL);
}

//close the linkedlist of connections
void clean(){
  struct connection_table* p;
  while(table){
    free(table->conn->buf);
    http_close(table->conn);
    p= table;
    table = table->prev;
    free(p);
  }
  free(table);
}

// TIMING AND INTERRUPT FUNCTIONS
static void handle_sigalrm(int signo);

// timestamp()
//    Return the current time as a real number of seconds.
double timestamp(void) {
    struct timeval now;
    gettimeofday(&now, NULL);
    return now.tv_sec + (double) now.tv_usec / 1000000;
}


// sleep_for(delay)
//    Sleep for `delay` seconds, or until an interrupt, whichever comes
//    first.
void sleep_for(double delay) {
    usleep((long) (delay * 1000000));
}


// interrupt_after(delay)
//    Cause an interrupt to occur after `delay` seconds. This interrupt will
//    make any blocked `read` system call terminate early, without returning
//    any data.
void interrupt_after(double delay) {
    static int signal_set = 0;
    if (!signal_set) {
        struct sigaction sa;
        sa.sa_handler = handle_sigalrm;
        sigemptyset(&sa.sa_mask);
        sa.sa_flags = 0;
        int r = sigaction(SIGALRM, &sa, NULL);
        if (r < 0) {
            perror("sigaction");
            exit(1);
        }
        signal_set = 1;
    }

    struct itimerval timer;
    timerclear(&timer.it_interval);
    timer.it_value.tv_sec = (long) delay;
    timer.it_value.tv_usec = (long) ((delay - timer.it_value.tv_sec) * 1000000);
    int r = setitimer(ITIMER_REAL, &timer, NULL);
    if (r < 0) {
        perror("setitimer");
        exit(1);
    }
}


// interrupt_cancel()
//    Cancel any outstanding interrupt.
void interrupt_cancel(void) {
    struct itimerval timer;
    timerclear(&timer.it_interval);
    timerclear(&timer.it_value);
    int r = setitimer(ITIMER_REAL, &timer, NULL);
    if (r < 0) {
        perror("setitimer");
        exit(1);
    }
}


// This is a helper function for `interrupt_after`.
static void handle_sigalrm(int signo) {
    (void) signo;
}


// HELPER FUNCTIONS FOR CODE ABOVE

// http_consume_headers(conn, eof)
//    Parse the response represented by `conn->buf`. Returns 1
//    if more data should be read into `conn->buf`, 0 if the response is
//    complete.
static int http_consume_headers(http_connection *conn, int eof) {
    size_t i = 0;
    while ((conn->state == HTTP_INITIAL || conn->state == HTTP_HEADERS)
           && i + 2 <= conn->len) {
        if (conn->buf[i] == '\r' && conn->buf[i+1] == '\n') {
            conn->buf[i] = 0;
            if (conn->state == HTTP_INITIAL) {
                int minor;
                if (sscanf(conn->buf, "HTTP/1.%d %d",
                           &minor, &conn->status_code) == 2)
                    conn->state = HTTP_HEADERS;
                else
                    conn->state = HTTP_BROKEN;
            } else if (i == 0)
                conn->state = HTTP_BODY;
            else if (strncmp(conn->buf, "Content-Length: ", 16) == 0) {
                conn->content_length = strtoul(conn->buf + 16, NULL, 0);
                conn->has_content_length = 1;
            }
            memmove(conn->buf, conn->buf + i + 2, conn->len - (i + 2));
            conn->len -= i + 2;
            i = 0;
        } else
            ++i;
    }

    if (conn->state == HTTP_BODY
        && (conn->has_content_length || eof)
        && conn->len >= conn->content_length)
        conn->state = HTTP_DONE;
    if (eof)
        conn->state = (conn->state == HTTP_DONE ? HTTP_CLOSED : HTTP_BROKEN);
    return conn->state >= 0;
}


// usage()
//    Explain how pong61 should be run.
static void usage(void) {
    fprintf(stderr, "Usage: ./pong61 [-h HOST] [-p PORT] [USER]\n");
    exit(1);
}

//set the delay time. put it in critical section with locks
void set_delay(double delay){
  pthread_mutex_lock(&mutex);
  request_delay = delay;
  pthread_mutex_unlock(&mutex);
}

//adding connections to table
static void add_connentry(void* conn){
  pthread_mutex_lock(&mutex);
  // if (cache_size > 30) 
  //    pthread_cond_signal(&count_threshold_cv);

  struct connection_table* t = (struct connection_table*) malloc(sizeof(struct connection_table));
  
  if(cache_size == 0){
    table = t;
    table->conn =(http_connection*)conn;
   
    table->prev = NULL;
    table->next = NULL;
  }
  else{
   
    t->conn = conn;
    t->next = table->next;
    table->next = t;
    t->prev = table;
    table = t;
  }
 
  cache_size++;
  
  pthread_mutex_unlock(&mutex);

  }


/*static void* remove_connentries(){
   pthread_mutex_lock(&mutex);
   if(cache_size == 0){
     pthread_mutex_unlock(&mutex);
     return;
     }
   pthread_cond_wait(&count_threshold_cv,&mutex);
   struct connection_table *p = table;
   struct connection_table* next = NULL;
   while(p)
   {
     if(p->conn->state == HTTP_DONE|| p->conn->state== HTTP_BROKEN ||
        p->conn->state == HTTP_CLOSED)
     {
       if(next != NULL && next->prev == p)
	 next->prev = p->prev;
       if(p->prev != NULL && p->prev->next == p)
	 p->prev->next = p->next;
       http_close(p->conn); 
       cache_size--;
       break;
     }
     next = p;
     p = p->prev;
     
   }
   pthread_mutex_unlock(&mutex);
   return NULL;
   }*/

//removing connections in table i.e when a connection is reused remove it 
// from table.
static void remove_connentry(void* conn){
   pthread_mutex_lock(&mutex);
   if(cache_size == 0){
     pthread_mutex_unlock(&mutex);
     return;
   }

   struct connection_table *p = table;
   struct connection_table* next = NULL;
   while(p)
   {
     if((struct http_connection*)conn == p->conn)
     {
       if(next != NULL && next->prev == p)
	 next->prev = p->prev;
       if(p->prev != NULL && p->prev->next == p)
	 p->prev->next = p->next;
       //http_close(p->conn); 
       cache_size--;
       break;
     }
     next = p;
     p = p->prev;
     
   }
   pthread_mutex_unlock(&mutex);
   return;
}

